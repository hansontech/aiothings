var https = require('https');
const config = require('./config');
// Load the SDK for JavaScript
const AWS = require('aws-sdk');
// Set the region 
console.log(config.DynamoDB_TABLE_NAME);
AWS.config.update({region: `${config.DYNAMODB_TABLE_REGION}`});
// Set the Dynamodb Table
const Device_TABLE_NAME = config.DynamoDB_TABLE_NAME;

// The DocumentClient class allows us to interact with DynamoDB using normal objects.
const dynamoDb = new AWS.DynamoDB.DocumentClient();
// AWS api reference
// https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/GettingStarted.NodeJs.03.html

// Search User identity information from Dynamodb
let findDataBySerialNumber = ( values,callback ) => {

      dynamoDb.query({
        TableName: Device_TABLE_NAME,
        KeyConditionExpression: 'serialNumber = :a',
        ExpressionAttributeValues: {
            ':a': values
        }
      }, (err, data) => {
        if (err) {
          console.log(err);
          res.status(500).json({
            message: 'Could not load your device info',
          }).end();
          callback( err );
        } else {
          //console.log(data.Count);
          callback( null, data );
        }
      });
}

// Put IoT cert info into Dynamodb
let dbInsertCertinfo = ( userId, certId, thingId, desc, publicKey, privateKey, callback ) => {
  let itemList =  {
    'UserId': userId,
    'CertId': certId,
    'ThingId': thingId,
    'ThingDesc': desc,
    'PrivateKey': privateKey,
    'PublicKey': publicKey
  };
  var params = {
    TableName: Device_TABLE_NAME,
    Item: itemList
  };
  // console.log('db item: ', itemList)
  dynamoDb.put(params, function(err, data) {
    if (err) {
      console.log(err);
      callback( err );
    } else {
      callback( null, itemList );
    }
  });
}

// Put IoT cert info into Dynamodb
let dbUpdateCertinfo = ( userId, iotcert, desc, callback ) => {
   
  dynamoDb.update({
    TableName: Device_TABLE_NAME,
    Key:{
        'UserId': userId,
        'CertId': iotcert
    },
    UpdateExpression: 'set ThingDesc = :desc',
    ExpressionAttributeValues:{
        ':desc': desc
    },
    ReturnValues:'UPDATED_NEW'
  }, (err, data) => {
    if (err) {
      console.log(err);
      callback( err );
    } else {
      callback( null,data );
    }
  });
}

// Remove IoT cert of the user from Dynamodb
let dbDeleteCertinfo = ( userId, iotcert, callback ) => {
 
  var params = {
    TableName: Device_TABLE_NAME,
    Item: {
      'UserId': userId,
      'CertId': iotcert
    }
  };
  dynamoDb.delete(params, function(err, data) {
    if (err) {
      console.log(err);
      callback( err );
    } else {
      callback( null,data );
    }
  });

}

// List all IoT cert info of the user from Dynamodb
let dbListCertinfo = ( userId, callback ) => {

  var params = {
    TableName: Device_TABLE_NAME,
    ProjectionExpression:'UserId, CertId, ThingId, ThingDesc',
    KeyConditionExpression: '#userid = :userid',
    ExpressionAttributeNames:{
        '#userid': 'UserId'
    },
    ExpressionAttributeValues: {
        ':userid': userId
    }
  };

  dynamoDb.query(params, function(err, data) {
    if (err) {
        console.log('Unable to query. Error: ', JSON.stringify(err, null, 2));
    } else {
        console.log('Query succeeded.');
        let dataJson = JSON.stringify(data.Items)
        callback( null, dataJson );
    }
  });  
}

// Get IoT cert info from Dynamodb
let dbGetCertinfo = ( userId, iotcert, callback ) => {

  var params = {
    TableName: Device_TABLE_NAME,
    KeyConditionExpression: '#userid = :userid and #certid = :certid',
    // Projection of all fields as output
    ExpressionAttributeNames:{
        '#userid': 'UserId',
        '#certid': 'CertId'
    },
    ExpressionAttributeValues: {
        ':userid': userId,
        ':certid': iotcert
    }
  };

  dynamoDb.query(params, function(err, data) {
    if (err) {
        console.log('getCertinfo: Unable to query. Error:', JSON.stringify(err, null, 2));
        callback(err)
    } else {
        console.log('getCertinfo: Query succeeded.');
        let dataJson = data.Items
        callback( null, dataJson );
    }
  });  
}

// AWS IOT reference
// Language examples
// https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/Iot.html
// Detail AWS IOT API information
// https://docs.aws.amazon.com/iot/latest/apireference/Welcome.html

// Apply cert & Attach thing, policy
let applyThingCert = ( userId, callback ) => {
  console.log('applyCert region: ', config.region)  
  console.log('userId: ', userId)  
  AWS.config.update({region: config.region});
  var iot = new AWS.Iot();
  var params = {
    setAsActive: true
  };
  // Create cert
  iot.createKeysAndCertificate(params, function(err, certData) {
    // console.log(certData);
    if (err){
      console.log(err, err.stack); // an error occurred
      callback(err)
    } 
    else{
      let datetime = (new Date()).getTime()
      console.log('applyThingCert: certData: ', certData)
      let thingId = userId + '_' + datetime
       // Create IoT Policy for above cert
       var params = {
        policyDocument: config.POLICY_DOCUMENT, /* required */
        policyName: thingId /* required */
      };
      console.log('policy params: ', params)
      iot.createPolicy(params, function(err, data) {
        if (err) {
          console.log(err, err.stack); // an error occurred
          callback(err)
        } 
        else{
          // Attach policy for cert
          var params = {
            policyName: thingId, /* required */
            target: certData.certificateArn /* required */
          };
          iot.attachPolicy(params, function(err, data) {
            if (err) {
              console.log(err, err.stack); // an error occurred
              callback(err)
            }
            else {
              // Create thing for cert
              var params = {
                thingName: thingId, /* required */
                attributePayload: {
                  attributes: {
                    'Application': 'AIOT',
                    'UserId': userId                  
                  },
                  merge: true || false
                }
              };
              iot.createThing(params, function(err, data) {
                if (err) {
                  console.log(err, err.stack); // an error occurred
                  callback(err)
                }
                else {
                  let certArn = certData.certificateArn
                  let certId = certData.certificateId
                  // Attach thing for cert
                  var params = {
                    principal: certArn, /* required */
                    thingName: thingId /* required */
                  };
                 
                  iot.attachThingPrincipal(params, function(err, thingData) {
                    if (err) {
                      console.log(err, err.stack); // an error occurred
                      callback(err)
                    }
                    else {
                      callback( null, certId, thingId, certData);
                    }
                  });
                }
              });
            }
          });
        }
      });
    }                
  });
}

// remove a specific cert & thing, policy
let cancelThingCert = (certId, thingId, callback ) => {
  AWS.config.update({region: config.region});
  var iot = new AWS.Iot();
  var params = {
    setAsActive: true || false
  };
  // Lists the principals associated with the specified thing.
  let listPrincipalsThingParams = {
    thingName: thingId /* required */
  };
  iot.listThingPrincipals(listPrincipalsThingParams, function(err, principalsData) {
    if (err) {
      console.log(err, err.stack); // an error occurred
      callback(err)
    }
    else{
      console.log('listThingPricipals: principals: ', principalsData);           // successful response
      // Lists the policies attached to the specified thing group.
      let principal = principalsData.principals[0]
      let certArn = principal
      let listPoliciesParams = {
        target: certArn, /* required */
        // marker: 'STRING_VALUE',
        // pageSize: 1,
        // recursive: false
      };
      console.log('listPoliciesParams: ', listPoliciesParams)
      iot.listAttachedPolicies(listPoliciesParams, function(err, policyListData) {
        if (err) {
          console.log(err, err.stack); // an error occurred
          callback(err)
        }
        else{
          let policyList = policyListData.policies
          console.log('policyList: ', policyList);           // successful response
          // for all policies attached to this certificate
          for (policy in policyList) {
            // Delete policy
            let deletePolicyParams = {
              policyName: policy.policyName /* required */
            };
            iot.deletePolicy(deletePolicyParams, function(err, data) {
              if (err) console.log(err, err.stack); // an error occurred
              else     console.log(data);           // successful response
            }); // delete policy
          }
          var deleteCertParams = {
            certificateId: certId, /* required */
            forceDelete: true
          };
          iot.deleteCertificate(deleteCertParams, function(err, data) {
            if (err) {
              console.log(err, err.stack); // an error occurred
              callback(err)
            }
            else{
              console.log(data);           // successful response
              // Delete thing
              let deleteThingParams = {
                thingName: thingId, /* required */
                expectedVersion: 0
              };
              iot.deleteThing(deleteThingParams, function(err, data) {
                if (err) {
                  console.log(err, err.stack); // an error occurred
                  callback(err)
                }
                else{
                  console.log(data);           // successful response
                  callback( null );
                }
              }); // delete thing
            }
          }); // delete certificate
        }
      }); // list policies of certificate
    } 
  }); // list certificate(s)
}

// Retrieve certificate details from an existing certificate id
let getCertPem = ( certId, callback ) => {
  AWS.config.update({region: config.region});
  var iot = new AWS.Iot();
  var params = {
    certificateId: certId /* required */
  };
  iot.describeCertificate(params, function(err, data) {
    if (err) {
      console.log(err, err.stack); // an error occurred
      callback(err)
    } else {
      console.log('certId: ', certId, ': ', data);           // successful response
      console.log('certPem: ', data.certificateDescription.certificatePem);           // successful response
      callback(null, { 'CertPem' : data.certificateDescription.certificatePem } )
    }     
  });
}


// Get VeriSign Class 3 Public Primary G5 root CA certificate 
let getIoTRootCA = ( callback ) => {
  const RootCA_URL = config.RootCA_URL;
  https.get(RootCA_URL, ( response ) => {
    
    var body = [];
    //console.log(response.statusCode);
    //console.log(response.headers);
    //console.log(response);
    
    response.on('data', function (chunk) {
        body.push(chunk);
    });

    response.on('end', function () {
        body = Buffer.concat(body);
        //console.log(body.toString());
        callback( null, body.toString() );
    });
    
  })
}

module.exports = {
  
    findDataBySerialNumber,
    dbInsertCertinfo,
    dbUpdateCertinfo,
    dbListCertinfo,
    dbDeleteCertinfo,
    dbGetCertinfo,
    getIoTRootCA,
    applyThingCert,
    cancelThingCert,
    getCertPem
}
