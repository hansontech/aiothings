/** 
Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
This node.js Lambda function code creates certificate, attaches an IoT policy, IoT thing . 
It also activates the certificate. 
**/
// const config = require('./config');
const applyModel = require("utility");

/* 
    You should submit your device credentials to Lambda function through API Gateway for authenticating in DynamoDB.
    eg: {"userId":"YOUR_DEVICE_SERIAL_NUMBER","deviceToken":"TOKEN"}
*/
let create = (username, context, callback) => {

  const INTERLNAL_ERROR = 'Identical serial number error!';
  const GET_ROOT_CA_ERROR = 'Can not get Get VeriSign Class 3 Public Primary G5 root CA certificate! ';

  // Get device credentials
  var userId = username;
  // var deviceToken = event.deviceToken;
  // After the verification is complete, you can apply for a certificate for the device.
  applyModel.applycert(userId, (err, certData) => {

    // In order to be safe, you should write the certificate ID/Arn, indicating that the device has applied for a certificate.
    applyModel.putCertinfo(certData.certificateArn, userId, (err, putSuccess) => {

      if (err) callback(null, INTERLNAL_ERROR);

      // Don't forget to return CA certificate
      applyModel.getIoTRootCA((err, rootca) => {

        if (err) {
          console.log(err);
          callback(null, GET_ROOT_CA_ERROR);
        }
        var returnValues = certData;
        returnValues.RootCA = rootca;
        console.log(certData.certificateArn);
        // Don't forget to return CA certificate
        callback(null, returnValues);
      })

    });
  });
};

module.exports = {
  create
}
